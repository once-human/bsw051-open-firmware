/*
 * ONKAR-LIFE v2 tool service for the BSW051 (Realtek RTL8762D).
 *
 * Bluetooth comes up first (Realtek silent_ota sample, untouched). This file only
 * adds commands that the laptop sends over the "simple" service:
 *   write  0xB002  -> command
 *   notify 0xB003  <- reply
 *
 * Commands (byte 0 = opcode):
 *   01                       ping                      -> 81 'O' 'K' ver
 *   02                       battery                   -> 82 raw(u16) mv(u16) pct err
 *   03 pin level             pin output (held, SW pad) -> 83 pin level
 *   04 pin pull              read one pin (0/1/2 pull) -> 84 pin value
 *   05 pull                  read all pins             -> 85 bitmap[5] skipped[5]
 *   06 n bytes..             LCD raw write (1-line SPI on QSPI pins, CS framed) -> 86 n
 *   07 nw w.. nr             LCD write then read nr bytes on D1 and D0 -> 87 nr d1[nr] d0[nr]
 *   08 pin level ms(u16)     pulse pin, then invert    -> 88 pin
 *   09 hi lo rows(u16)       LCD fill: 0x02 00 2C 00 + rows*368 pixels (1-line) -> 89 rows
 *   0A pin                   release pin to input, no pull -> 8A pin
 * Every command finishes in well under 1 s, so the app task never stalls long.
 */
#include <string.h>
#include "rtl876x.h"
#include "rtl876x_rcc.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_gpio.h"
#include "rtl876x_adc.h"
#include "adc_lib.h"
#include "platform_utils.h"
#include "simple_ble_service.h"
#include "onkar_tool.h"

#define ONKAR_FW_VER        2
#define PIN_COUNT           39

/* Realtek reference QSPI LCD pins (qspi_lcd_platform.c) */
#define LCD_CS              P4_3
#define LCD_CLK             P4_0
#define LCD_D0              P4_2
#define LCD_D1              P4_1
#define LCD_D2              P0_6
#define LCD_D3              P0_7
#define LCD_WIDTH           368

extern T_SERVER_ID g_simp_service_id;

static uint64_t driven_mask = 0;     /* pins we are holding as outputs */
static bool adc_cal_done = false;
static bool lcd_bus_ready = false;

static void reply(uint8_t conn_id, uint8_t *d, uint16_t n)
{
    simp_ble_service_send_v3_notify(conn_id, g_simp_service_id, d, n);
}

static bool pin_valid(uint8_t pin)
{
    return (pin < PIN_COUNT) && (pin != 31);
}

/* ---------- pins ---------- */

static void pin_hold(uint8_t pin, uint8_t level)
{
    Pinmux_Config(pin, IDLE_MODE);
    Pad_Config(pin, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE,
               level ? PAD_OUT_HIGH : PAD_OUT_LOW);
    driven_mask |= ((uint64_t)1 << pin);
}

static void pin_release(uint8_t pin)
{
    Pinmux_Config(pin, IDLE_MODE);
    Pad_Config(pin, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
    driven_mask &= ~((uint64_t)1 << pin);
}

static void gpio_cfg(uint8_t pin, bool output, uint8_t pull, uint8_t level)
{
    Pinmux_Config(pin, DWGPIO);
    Pad_Config(pin, PAD_PINMUX_MODE, PAD_IS_PWRON,
               pull == 1 ? PAD_PULL_UP : (pull == 2 ? PAD_PULL_DOWN : PAD_PULL_NONE),
               output ? PAD_OUT_ENABLE : PAD_OUT_DISABLE,
               level ? PAD_OUT_HIGH : PAD_OUT_LOW);
    GPIO_InitTypeDef g;
    GPIO_StructInit(&g);
    g.GPIO_Pin = GPIO_GetPin(pin);
    g.GPIO_Mode = output ? GPIO_Mode_OUT : GPIO_Mode_IN;
    g.GPIO_ITCmd = DISABLE;
    GPIO_Init(&g);
    if (output)
    {
        GPIO_WriteBit(GPIO_GetPin(pin), level ? Bit_SET : Bit_RESET);
    }
}

static uint8_t pin_read(uint8_t pin, uint8_t pull)
{
    gpio_cfg(pin, false, pull, 0);
    platform_delay_us(30);
    uint8_t v = GPIO_ReadInputDataBit(GPIO_GetPin(pin));
    Pinmux_Config(pin, IDLE_MODE);
    Pad_Config(pin, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
    return v;
}

/* ---------- battery ---------- */

static uint8_t mv_to_pct(uint16_t mv)
{
    static const uint16_t mv_tab[]  = {3400, 3500, 3600, 3650, 3700, 3750, 3800, 3900, 4000, 4100, 4200};
    static const uint8_t  pct_tab[] = {0,    6,    14,   22,   32,   42,   52,   65,   78,   90,   100};
    if (mv <= mv_tab[0]) { return 0; }
    for (uint8_t i = 1; i < sizeof(mv_tab) / sizeof(mv_tab[0]); i++)
    {
        if (mv <= mv_tab[i])
        {
            return pct_tab[i - 1] + (uint8_t)((uint32_t)(mv - mv_tab[i - 1]) * (pct_tab[i] - pct_tab[i - 1]) /
                                              (mv_tab[i] - mv_tab[i - 1]));
        }
    }
    return 100;
}

uint16_t onkar_battery_read(uint16_t *raw_out, uint8_t *pct_out, int8_t *err_out)
{
    if (!adc_cal_done)
    {
        ADC_CalibrationInit();
        adc_cal_done = true;
    }
    RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);
    ADC_InitTypeDef s;
    ADC_StructInit(&s);
    s.ADC_SampleTime = 255;
    s.ADC_SchIndex[0] = INTERNAL_VBAT_MODE;
    s.ADC_Bitmap = 0x01;
    s.ADC_PowerAlwaysOnEn = ADC_POWER_ALWAYS_ON_ENABLE;
    ADC_Init(ADC, &s);
    ADC_INTConfig(ADC, ADC_INT_ONE_SHOT_DONE, ENABLE);
    ADC_ClearINTPendingBit(ADC, ADC_INT_ONE_SHOT_DONE);
    ADC_Cmd(ADC, ADC_ONE_SHOT_MODE, ENABLE);
    uint32_t guard = 0;
    while (ADC_GetINTStatus(ADC, ADC_INT_ONE_SHOT_DONE) == RESET && guard < 200000) { guard++; }
    ADC_ClearINTPendingBit(ADC, ADC_INT_ONE_SHOT_DONE);
    uint16_t raw = ADC_ReadRawData(ADC, 0);
    ADC_Cmd(ADC, ADC_ONE_SHOT_MODE, DISABLE);
    ADC_ErrorStatus err = NO_ERROR;
    float v = ADC_GetVoltage(DIVIDE_SINGLE_MODE, (int32_t)raw, &err);
    uint16_t mv = (v > 0 && v < 10000) ? (uint16_t)v : 0;
    if (raw_out) { *raw_out = raw; }
    if (pct_out) { *pct_out = mv_to_pct(mv); }
    if (err_out) { *err_out = (int8_t)err; }
    return mv;
}

/* ---------- LCD bit-bang (single line on the QSPI pins) ---------- */

static void lcd_bus_init(void)
{
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
    gpio_cfg(LCD_CS, true, 0, 1);
    gpio_cfg(LCD_CLK, true, 0, 0);
    gpio_cfg(LCD_D0, true, 0, 0);
    gpio_cfg(LCD_D1, false, 0, 0);
    gpio_cfg(LCD_D2, true, 0, 1);
    gpio_cfg(LCD_D3, true, 0, 1);
    lcd_bus_ready = true;
}

static inline void lcd_byte(uint8_t b)
{
    uint32_t clk = GPIO_GetPin(LCD_CLK), d0 = GPIO_GetPin(LCD_D0);
    for (int8_t i = 7; i >= 0; i--)
    {
        if ((b >> i) & 1) { GPIO_SetBits(d0); } else { GPIO_ResetBits(d0); }
        GPIO_SetBits(clk);
        GPIO_ResetBits(clk);
    }
}

static uint8_t lcd_read_byte(uint8_t data_pin)
{
    uint32_t clk = GPIO_GetPin(LCD_CLK), din = GPIO_GetPin(data_pin);
    uint8_t v = 0;
    for (int8_t i = 7; i >= 0; i--)
    {
        GPIO_SetBits(clk);
        v = (v << 1) | (GPIO_ReadInputDataBit(din) ? 1 : 0);
        GPIO_ResetBits(clk);
    }
    return v;
}

static void cs(uint8_t level)
{
    if (level) { GPIO_SetBits(GPIO_GetPin(LCD_CS)); } else { GPIO_ResetBits(GPIO_GetPin(LCD_CS)); }
}

/* ---------- command handler ---------- */

void onkar_tool_handle(uint8_t conn_id, uint8_t *p, uint16_t len)
{
    uint8_t r[244];
    if (p == NULL || len == 0) { return; }
    memset(r, 0, sizeof(r));
    r[0] = p[0] | 0x80;

    switch (p[0])
    {
    case 0x01:
        r[1] = 'O'; r[2] = 'K'; r[3] = ONKAR_FW_VER;
        reply(conn_id, r, 4);
        break;

    case 0x02:
        {
            uint16_t raw = 0; uint8_t pct = 0; int8_t err = 0;
            uint16_t mv = onkar_battery_read(&raw, &pct, &err);
            r[1] = raw & 0xff; r[2] = raw >> 8; r[3] = mv & 0xff; r[4] = mv >> 8; r[5] = pct; r[6] = (uint8_t)err;
            reply(conn_id, r, 7);
        }
        break;

    case 0x03:
        if (len >= 3 && pin_valid(p[1]))
        {
            pin_hold(p[1], p[2]);
            r[1] = p[1]; r[2] = p[2];
            reply(conn_id, r, 3);
        }
        break;

    case 0x04:
        if (len >= 3 && pin_valid(p[1]))
        {
            RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
            r[1] = p[1]; r[2] = pin_read(p[1], p[2]);
            reply(conn_id, r, 3);
        }
        break;

    case 0x05:
        {
            uint8_t pull = (len >= 2) ? p[1] : 0;
            uint64_t bits = 0, skipped = 0;
            RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
            for (uint8_t pin = 0; pin < PIN_COUNT; pin++)
            {
                bool lcd_pin = lcd_bus_ready && (pin == LCD_CS || pin == LCD_CLK || pin == LCD_D0 ||
                                                 pin == LCD_D1 || pin == LCD_D2 || pin == LCD_D3);
                if (!pin_valid(pin) || (driven_mask & ((uint64_t)1 << pin)) || lcd_pin)
                {
                    skipped |= ((uint64_t)1 << pin);
                    continue;
                }
                if (pin_read(pin, pull)) { bits |= ((uint64_t)1 << pin); }
            }
            memcpy(&r[1], &bits, 5);
            memcpy(&r[6], &skipped, 5);
            reply(conn_id, r, 11);
        }
        break;

    case 0x06:
        if (len >= 2 && p[1] <= len - 2)
        {
            if (!lcd_bus_ready) { lcd_bus_init(); }
            cs(0);
            for (uint8_t i = 0; i < p[1]; i++) { lcd_byte(p[2 + i]); }
            cs(1);
            r[1] = p[1];
            reply(conn_id, r, 2);
        }
        break;

    case 0x07:
        if (len >= 3 && p[1] <= len - 3)
        {
            uint8_t nw = p[1], nr = p[2 + nw];
            if (nr > 100) { nr = 100; }
            if (!lcd_bus_ready) { lcd_bus_init(); }
            cs(0);
            for (uint8_t i = 0; i < nw; i++) { lcd_byte(p[2 + i]); }
            for (uint8_t i = 0; i < nr; i++) { r[2 + i] = lcd_read_byte(LCD_D1); }
            cs(1);
            /* second try: same frame, sampling D0 (some panels answer on D0) */
            gpio_cfg(LCD_D0, false, 0, 0);
            cs(0);
            gpio_cfg(LCD_D0, true, 0, 0);
            for (uint8_t i = 0; i < nw; i++) { lcd_byte(p[2 + i]); }
            gpio_cfg(LCD_D0, false, 0, 0);
            for (uint8_t i = 0; i < nr; i++) { r[2 + nr + i] = lcd_read_byte(LCD_D0); }
            cs(1);
            gpio_cfg(LCD_D0, true, 0, 0);
            r[1] = nr;
            reply(conn_id, r, 2 + 2 * nr);
        }
        break;

    case 0x08:
        if (len >= 5 && pin_valid(p[1]))
        {
            uint16_t ms = p[3] | (p[4] << 8);
            if (ms > 800) { ms = 800; }
            pin_hold(p[1], p[2]);
            platform_delay_ms(ms);
            pin_hold(p[1], !p[2]);
            r[1] = p[1];
            reply(conn_id, r, 2);
        }
        break;

    case 0x09:
        if (len >= 5)
        {
            uint8_t hi = p[1], lo = p[2];
            uint16_t rows = p[3] | (p[4] << 8);
            if (rows > 48) { rows = 48; }
            if (!lcd_bus_ready) { lcd_bus_init(); }
            cs(0);
            lcd_byte(0x02); lcd_byte(0x00); lcd_byte(0x2C); lcd_byte(0x00);
            for (uint32_t px = 0; px < (uint32_t)rows * LCD_WIDTH; px++) { lcd_byte(hi); lcd_byte(lo); }
            cs(1);
            r[1] = (uint8_t)rows;
            reply(conn_id, r, 2);
        }
        break;

    case 0x0A:
        if (len >= 2 && pin_valid(p[1]))
        {
            pin_release(p[1]);
            r[1] = p[1];
            reply(conn_id, r, 2);
        }
        break;

    default:
        r[1] = 0xEE;
        reply(conn_id, r, 2);
        break;
    }
}
