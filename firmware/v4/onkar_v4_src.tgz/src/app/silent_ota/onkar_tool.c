/*
 * ONKAR-LIFE v3 tool service for the BSW051 (Realtek RTL8762D).
 *
 * Bluetooth comes up first (Realtek silent_ota sample, untouched). This file only
 * runs when the laptop asks, over the "simple" service:
 *   write  0xB002  -> command        notify 0xB003  <- reply (opcode | 0x80)
 *
 * Safety (new in v3):
 *   - H_0 / H_1 / H_2 (MICBIAS, 32 kHz crystal) are refused by every command.
 *   - Hardware watchdog (8 s). Armed only after the app task has proven it is alive
 *     (3 heartbeats), so a mistake here can never cause a boot loop.
 *     Paused automatically as soon as a firmware update starts.
 *   - Dead-man switch: every pin we drive is released (input + pull-down, which also
 *     turns a motor transistor off) when the laptop disconnects or goes quiet for 30 s.
 *   - Long loops (pin hunt) kick the watchdog themselves.
 *
 * Commands:
 *   01                         ping                          -> 81 'O' 'K' ver
 *   02                         battery (chip VBAT pin)        -> 82 raw(u16) mv(u16) pct err
 *   03 pin level               hold pin as output             -> 83 pin level | 83 EE pin (refused)
 *   04 pin pull                read one pin                   -> 84 pin value
 *   05 pull                    read all safe pins             -> 85 bits[5] skipped[5]
 *   08 pin level ms(u16)       pulse (<= 1000 ms), then release -> 88 pin
 *   0A pin                     release pin                    -> 8A pin
 *   0B                         release everything             -> 8B count
 *   10                         status                         -> 90 ver uptime(u32) reset_reason wdg driven[5] hb(u32)
 *   11                         ADC sweep P2_0..P2_7 + VBAT    -> 91 then 9 x (raw u16, mv u16)
 *   12 scl sda                 I2C scan                       -> 92 status count map[16]
 *   13 scl sda addr reg n      I2C read n (<= 64)             -> 93 status n data
 *   14 scl sda addr n data..   I2C write                      -> 94 status
 *   15 rst flags mask[5]       display-bus hunt; flags: pull(bits0-1) protos(bits4-6, 0=all)   -> 95 status ncand nhits {cs clk mosi miso proto d0 d1 d2 d3}...
 *   16 cs clk mosi miso dc flags nw w.. nr    SPI transfer    -> 96 nr data
 *   17 cs clk mosi dc flags nh h.. hi lo count(u32)  pixel fill -> 97 status
 *   18                         read-only pad dump pins 0..38  -> 98 {b0 b1 pinmux} x 39
 *   19 pin ms(u16)             float test then exact restore  -> 99 pin 0 | 99 pin 80 (boot output, skipped)
 * v4: every pin goes back to its exact boot state when released (not pull-down).
 */
#include <string.h>
#include "rtl876x.h"
#include "rtl876x_rcc.h"
#include "rtl876x_pinmux.h"
#include "rtl876x_gpio.h"
#include "rtl876x_adc.h"
#include "rtl876x_wdg.h"
#include "adc_lib.h"
#include "platform_utils.h"
#include "os_timer.h"
#include "os_sched.h"
#include "app_msg.h"
#include "app_task.h"
#include "simple_ble_service.h"
#include "onkar_tool.h"

#define ONKAR_FW_VER        4
#define PIN_MAX             35          /* P4_3; 36..38 are H_0..H_2 and are never touched */
#define DEADMAN_MS          30000
#define HUNT_MAX_CAND       32
#define HUNT_MAX_HITS       20

extern T_SERVER_ID g_simp_service_id;

static uint64_t driven_mask = 0;
static bool adc_cal_done = false;
static uint64_t last_cmd_ms = 0;
static void *hb_timer = NULL;
static volatile uint32_t hb_sent = 0, hb_seen = 0, hb_seen_at_last_tick = 0;
static bool wdg_armed = false, wdg_paused = false;
static uint8_t boot_reset_reason = 0;

/* ------------------------------------------------------------------ helpers */

static void reply(uint8_t conn_id, uint8_t *d, uint16_t n)
{
    simp_ble_service_send_v3_notify(conn_id, g_simp_service_id, d, n);
}

static bool pin_valid(uint8_t pin)
{
    return (pin <= PIN_MAX) && (pin != 31);
}

static uint64_t bit(uint8_t pin) { return ((uint64_t)1) << pin; }

static void wdg_kick(void)
{
    if (wdg_armed && !wdg_paused) { WDG_Restart(); }
}

/* ------------------------------------------------------------------ pins
 * v4: before we touch a pin the first time, its exact boot state (2 AON pad bytes +
 * pinmux function) is saved. "Release" puts those exact bytes back, so a pin the
 * board relies on (power hold, chip enable...) returns to what it was at boot.
 */
extern const uint16_t PINADDR_TABLE[];
static uint8_t orig_b0[PIN_MAX + 1], orig_b1[PIN_MAX + 1], orig_pmx[PIN_MAX + 1];
static uint64_t orig_saved = 0;

static uint8_t pmx_get(uint8_t pin)
{
    return (PINMUX->CFG[pin >> 2] >> ((pin & 3) << 3)) & 0xFF;
}

static void remember(uint8_t pin)
{
    if (pin > PIN_MAX || (orig_saved & (((uint64_t)1) << pin))) { return; }
    uint8_t a = (uint8_t)PINADDR_TABLE[pin];
    orig_b0[pin] = btaon_fast_read_safe(a);
    orig_b1[pin] = btaon_fast_read_safe(a + 1);
    orig_pmx[pin] = pmx_get(pin);
    orig_saved |= ((uint64_t)1) << pin;
}

static void restore(uint8_t pin)
{
    if (pin > PIN_MAX || !(orig_saved & (((uint64_t)1) << pin))) { return; }
    uint8_t a = (uint8_t)PINADDR_TABLE[pin];
    /* pad first (so the pin never floats through a wrong function), then pinmux */
    btaon_fast_write_safe(a, orig_b0[pin]);
    btaon_fast_write_safe(a + 1, orig_b1[pin]);
    Pinmux_Config(pin, orig_pmx[pin]);
}

/* boot-time state says this pad is a software-driven output: somebody relies on it */
static bool pin_is_sw_output(uint8_t pin)
{
    uint8_t a = (uint8_t)PINADDR_TABLE[pin];
    uint8_t b0 = btaon_fast_read_safe(a), b1 = btaon_fast_read_safe(a + 1);
    return ((b1 & 0x02) == 0) && (b0 & 0x02);
}

static void pin_hold(uint8_t pin, uint8_t level)
{
    remember(pin);
    Pinmux_Config(pin, IDLE_MODE);
    Pad_Config(pin, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_ENABLE,
               level ? PAD_OUT_HIGH : PAD_OUT_LOW);
    driven_mask |= bit(pin);
}

/* released = back to the exact state it had at boot */
static void pin_release(uint8_t pin)
{
    if (orig_saved & bit(pin)) { restore(pin); }
    else
    {
        Pinmux_Config(pin, IDLE_MODE);
        Pad_Config(pin, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_DOWN, PAD_OUT_DISABLE, PAD_OUT_LOW);
    }
    driven_mask &= ~bit(pin);
}

static uint8_t release_all(void)
{
    uint8_t n = 0;
    for (uint8_t pin = 0; pin <= PIN_MAX; pin++)
    {
        if (driven_mask & bit(pin)) { pin_release(pin); n++; }
    }
    driven_mask = 0;
    return n;
}

static PAD_Pull_Mode pull_of(uint8_t pull)
{
    return pull == 1 ? PAD_PULL_UP : (pull == 2 ? PAD_PULL_DOWN : PAD_PULL_NONE);
}

/* pin owned by the GPIO block (fast register access via DATADIR/DATAOUT/DATAIN) */
static void gpio_take(uint8_t pin, uint8_t pull)
{
    remember(pin);
    Pinmux_Config(pin, DWGPIO);
    Pad_Config(pin, PAD_PINMUX_MODE, PAD_IS_PWRON, pull_of(pull), PAD_OUT_ENABLE, PAD_OUT_LOW);
    GPIO_InitTypeDef g;
    GPIO_StructInit(&g);
    g.GPIO_Pin = GPIO_GetPin(pin);
    g.GPIO_Mode = GPIO_Mode_IN;
    g.GPIO_ITCmd = DISABLE;
    GPIO_Init(&g);
}

static inline void g_out(uint32_t m, uint8_t level)
{
    if (level) { GPIO->DATAOUT |= m; } else { GPIO->DATAOUT &= ~m; }
    GPIO->DATADIR |= m;
}
static inline void g_in(uint32_t m) { GPIO->DATADIR &= ~m; }
static inline void g_set(uint32_t m) { GPIO->DATAOUT |= m; }
static inline void g_clr(uint32_t m) { GPIO->DATAOUT &= ~m; }
static inline uint32_t g_read(void) { return GPIO->DATAIN; }
static inline void tiny_delay(void) { for (volatile uint8_t i = 0; i < 4; i++) { __NOP(); } }

/* returns 0/1, or 0x80|level if the pin is a software-driven output (not touched) */
static uint8_t pin_read(uint8_t pin, uint8_t pull)
{
    uint8_t a = (uint8_t)PINADDR_TABLE[pin];
    uint8_t b0 = btaon_fast_read_safe(a), b1 = btaon_fast_read_safe(a + 1);
    if (((b1 & 0x02) == 0) && (b0 & 0x02)) { return 0x80 | (b0 & 1); }
    bool was_saved = (orig_saved & bit(pin)) != 0;
    uint8_t sb0 = b0, sb1 = b1, spmx = pmx_get(pin);
    if (pull == 3) { pull = (b0 & 0x04) ? ((b0 & 0x08) ? 2 : 1) : 0; }   /* keep current pull */
    gpio_take(pin, pull);
    platform_delay_us(30);
    uint8_t v = (g_read() & GPIO_GetPin(pin)) ? 1 : 0;
    btaon_fast_write_safe(a, sb0);
    btaon_fast_write_safe(a + 1, sb1);
    Pinmux_Config(pin, spmx);
    if (!was_saved) { orig_saved &= ~bit(pin); }
    return v;
}

/* ------------------------------------------------------------------ ADC */

static uint8_t mv_to_pct(uint16_t mv)
{
    static const uint16_t mv_tab[]  = {3400, 3500, 3600, 3650, 3700, 3750, 3800, 3900, 4000, 4100, 4200};
    static const uint8_t  pct_tab[] = {0,    6,    14,   22,   32,   42,   52,   65,   78,   90,   100};
    if (mv <= mv_tab[0]) { return 0; }
    for (uint8_t i = 1; i < sizeof(mv_tab) / sizeof(mv_tab[0]); i++)
    {
        if (mv <= mv_tab[i])
        {
            return pct_tab[i - 1] + (uint8_t)((uint32_t)(mv - mv_tab[i - 1]) * (pct_tab[i] - pct_tab[i - 1]) /
                                              (mv_tab[i] - mv_tab[i - 1]));
        }
    }
    return 100;
}

/* one-shot conversion of one schedule entry, divide mode (0..3.3 V on pins) */
static uint16_t adc_once(uint16_t sch, uint16_t *raw_out, int8_t *err_out)
{
    if (!adc_cal_done)
    {
        ADC_CalibrationInit();
        adc_cal_done = true;
    }
    RCC_PeriphClockCmd(APBPeriph_ADC, APBPeriph_ADC_CLOCK, ENABLE);
    ADC_InitTypeDef s;
    ADC_StructInit(&s);
    s.ADC_SampleTime = 255;
    s.ADC_SchIndex[0] = sch;
    s.ADC_Bitmap = 0x01;
    s.ADC_PowerAlwaysOnEn = ADC_POWER_ALWAYS_ON_ENABLE;
    ADC_Init(ADC, &s);
    ADC_INTConfig(ADC, ADC_INT_ONE_SHOT_DONE, ENABLE);
    ADC_ClearINTPendingBit(ADC, ADC_INT_ONE_SHOT_DONE);
    ADC_Cmd(ADC, ADC_ONE_SHOT_MODE, ENABLE);
    uint32_t guard = 0;
    while (ADC_GetINTStatus(ADC, ADC_INT_ONE_SHOT_DONE) == RESET && guard < 200000) { guard++; }
    ADC_ClearINTPendingBit(ADC, ADC_INT_ONE_SHOT_DONE);
    uint16_t raw = ADC_ReadRawData(ADC, 0);
    ADC_Cmd(ADC, ADC_ONE_SHOT_MODE, DISABLE);
    ADC_ErrorStatus err = NO_ERROR;
    float v = ADC_GetVoltage(DIVIDE_SINGLE_MODE, (int32_t)raw, &err);
    if (raw_out) { *raw_out = raw; }
    if (err_out) { *err_out = (guard >= 200000) ? -9 : (int8_t)err; }
    return (v > 0 && v < 10000) ? (uint16_t)v : 0;
}

uint16_t onkar_battery_read(uint16_t *raw_out, uint8_t *pct_out, int8_t *err_out)
{
    uint16_t mv = adc_once(INTERNAL_VBAT_MODE, raw_out, err_out);
    if (pct_out) { *pct_out = mv_to_pct(mv); }
    return mv;
}

/* ------------------------------------------------------------------ I2C (bit-banged, open drain) */

typedef struct { uint32_t scl, sda; } T_I2C;

static void i2c_hi(uint32_t m) { g_in(m); }          /* released: external/internal pull-up */
static void i2c_lo(uint32_t m) { g_out(m, 0); }
static void i2c_dly(void) { platform_delay_us(4); }
static bool i2c_scl_wait(T_I2C *b)
{
    for (uint16_t i = 0; i < 500; i++) { if (g_read() & b->scl) { return true; } platform_delay_us(2); }
    return false;
}
static void i2c_start(T_I2C *b)
{
    i2c_hi(b->sda); i2c_hi(b->scl); i2c_scl_wait(b); i2c_dly();
    i2c_lo(b->sda); i2c_dly(); i2c_lo(b->scl); i2c_dly();
}
static void i2c_stop(T_I2C *b)
{
    i2c_lo(b->sda); i2c_dly(); i2c_hi(b->scl); i2c_scl_wait(b); i2c_dly(); i2c_hi(b->sda); i2c_dly();
}
static bool i2c_wbyte(T_I2C *b, uint8_t v)          /* returns true on ACK */
{
    for (int8_t i = 7; i >= 0; i--)
    {
        if ((v >> i) & 1) { i2c_hi(b->sda); } else { i2c_lo(b->sda); }
        i2c_dly(); i2c_hi(b->scl); i2c_scl_wait(b); i2c_dly(); i2c_lo(b->scl);
    }
    i2c_hi(b->sda); i2c_dly(); i2c_hi(b->scl); i2c_scl_wait(b); i2c_dly();
    bool ack = (g_read() & b->sda) == 0;
    i2c_lo(b->scl); i2c_dly();
    return ack;
}
static uint8_t i2c_rbyte(T_I2C *b, bool ack)
{
    uint8_t v = 0;
    i2c_hi(b->sda);
    for (int8_t i = 7; i >= 0; i--)
    {
        i2c_dly(); i2c_hi(b->scl); i2c_scl_wait(b); i2c_dly();
        v = (v << 1) | ((g_read() & b->sda) ? 1 : 0);
        i2c_lo(b->scl);
    }
    if (ack) { i2c_lo(b->sda); } else { i2c_hi(b->sda); }
    i2c_dly(); i2c_hi(b->scl); i2c_scl_wait(b); i2c_dly(); i2c_lo(b->scl); i2c_hi(b->sda);
    return v;
}

/* 0 ok, 1 SDA stuck low, 2 SCL stuck low, 3 bad pins */
static uint8_t i2c_open(T_I2C *b, uint8_t scl, uint8_t sda)
{
    if (!pin_valid(scl) || !pin_valid(sda) || scl == sda) { return 3; }
    b->scl = GPIO_GetPin(scl); b->sda = GPIO_GetPin(sda);
    if (b->scl == b->sda) { return 3; }                 /* share one GPIO line */
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
    gpio_take(scl, 1); gpio_take(sda, 1);
    driven_mask |= bit(scl) | bit(sda);
    platform_delay_us(50);
    if ((g_read() & b->scl) == 0) { return 2; }
    if ((g_read() & b->sda) == 0)
    {
        for (uint8_t i = 0; i < 9 && (g_read() & b->sda) == 0; i++)   /* clock a stuck slave free */
        {
            i2c_lo(b->scl); i2c_dly(); i2c_hi(b->scl); i2c_dly();
        }
        if ((g_read() & b->sda) == 0) { return 1; }
        i2c_stop(b);
    }
    return 0;
}

/* ------------------------------------------------------------------ SPI (bit-banged) */

typedef struct { uint32_t cs, clk, mosi, miso, dc; uint8_t flags; } T_SPI;
#define SPI_F_9BIT    0x01      /* 3-wire 9-bit: D/C bit before each byte (first byte = command) */
#define SPI_F_DC      0x02      /* separate D/C pin: low for first byte, high after */
#define SPI_F_MISO_IS_MOSI 0x04 /* 3-wire: read back on the same line */

static inline void spi_bit_out(T_SPI *s, uint8_t b)
{
    if (b) { g_set(s->mosi); } else { g_clr(s->mosi); }
    tiny_delay(); g_set(s->clk); tiny_delay(); g_clr(s->clk);
}
static void spi_wbyte(T_SPI *s, uint8_t v, bool is_cmd)
{
    if (s->flags & SPI_F_9BIT) { spi_bit_out(s, is_cmd ? 0 : 1); }
    if (s->flags & SPI_F_DC) { if (is_cmd) { g_clr(s->dc); } else { g_set(s->dc); } }
    for (int8_t i = 7; i >= 0; i--) { spi_bit_out(s, (v >> i) & 1); }
}
static uint8_t spi_rbyte(T_SPI *s)
{
    uint8_t v = 0;
    for (int8_t i = 7; i >= 0; i--)
    {
        g_set(s->clk); tiny_delay();
        v = (v << 1) | ((g_read() & s->miso) ? 1 : 0);
        g_clr(s->clk); tiny_delay();
    }
    return v;
}

static bool spi_open(T_SPI *s, uint8_t cs, uint8_t clk, uint8_t mosi, uint8_t miso, uint8_t dc, uint8_t flags)
{
    if (!pin_valid(cs) || !pin_valid(clk) || !pin_valid(mosi)) { return false; }
    if (miso != 0xFF && !pin_valid(miso)) { return false; }
    if ((flags & SPI_F_DC) && !pin_valid(dc)) { return false; }
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
    s->flags = flags;
    s->cs = GPIO_GetPin(cs); s->clk = GPIO_GetPin(clk); s->mosi = GPIO_GetPin(mosi);
    s->miso = (miso == 0xFF) ? 0 : GPIO_GetPin(miso);
    s->dc = (flags & SPI_F_DC) ? GPIO_GetPin(dc) : 0;
    gpio_take(cs, 0); gpio_take(clk, 0); gpio_take(mosi, 0);
    driven_mask |= bit(cs) | bit(clk) | bit(mosi);
    if (miso != 0xFF && miso != mosi) { gpio_take(miso, 0); driven_mask |= bit(miso); }
    if (flags & SPI_F_DC) { gpio_take(dc, 0); g_out(s->dc, 1); driven_mask |= bit(dc); }
    g_out(s->cs, 1); g_out(s->clk, 0); g_out(s->mosi, 0);
    return true;
}

/* ------------------------------------------------------------------ display-bus hunt
 * Every combination of (cs, clk, mosi) among the candidate pins sends three kinds of
 * "read display ID" frames, then clocks 32 bits back while sampling ALL candidate pins at
 * once (GPIO DATAIN). A pin whose 32 bits are identical on two repeats and are neither
 * all-0 nor all-1 is a hit: something on the other end answered.
 *   proto 0: [0x04] + 32 read clocks              (SPI / 3-wire RDDID)
 *   proto 1: [0x03 0x00 0x04 0x00] + 32 clocks    (QSPI AMOLED drivers in 1-line read)
 *   proto 2: 9-bit [0|0x04] + 32 clocks           (3-wire 9-bit LCD drivers)
 */
typedef struct { uint8_t cs, clk, mosi, miso, proto; uint32_t data; } T_HIT;

static void hunt_frame(uint32_t cs, uint32_t clk, uint32_t mosi, uint8_t proto, uint32_t *samples)
{
    T_SPI s = { cs, clk, mosi, 0, 0, (uint8_t)(proto == 2 ? SPI_F_9BIT : 0) };
    g_out(mosi, 0); g_out(clk, 0); g_out(cs, 1);
    tiny_delay();
    g_clr(cs);
    if (proto == 1) { spi_wbyte(&s, 0x03, false); spi_wbyte(&s, 0x00, false); spi_wbyte(&s, 0x04, false); spi_wbyte(&s, 0x00, false); }
    else { spi_wbyte(&s, 0x04, true); }
    g_in(mosi);                                  /* let a 3-wire device drive the shared line */
    for (uint8_t i = 0; i < 32; i++)
    {
        g_set(clk); tiny_delay();
        samples[i] = g_read();
        g_clr(clk); tiny_delay();
    }
    g_set(cs);
    g_in(cs); g_in(clk);
}

static uint16_t hunt(uint8_t rst, uint8_t pull, uint8_t protos, uint64_t mask, uint8_t *out, uint16_t out_max, uint8_t *ncand_out)
{
    uint8_t cand[HUNT_MAX_CAND]; uint32_t cm[HUNT_MAX_CAND]; uint8_t n = 0;
    uint32_t used = 0, all = 0;
    RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
    if (rst != 0xFF && pin_valid(rst))
    {
        mask &= ~bit(rst);
        pin_hold(rst, 0); platform_delay_ms(20); pin_hold(rst, 1); platform_delay_ms(150);
    }
    for (uint8_t pin = 0; pin <= PIN_MAX && n < HUNT_MAX_CAND; pin++)
    {
        if (!(mask & bit(pin)) || !pin_valid(pin) || (driven_mask & bit(pin))) { continue; }
        if (pin_is_sw_output(pin)) { continue; }
        uint32_t m = GPIO_GetPin(pin);
        if (m == 0 || (used & m)) { continue; }      /* two pads on one GPIO line: keep the first */
        used |= m; cand[n] = pin; cm[n] = m; n++; all |= m;
        gpio_take(pin, pull);
    }
    *ncand_out = n;
    uint16_t hits = 0;
    uint32_t s1[32], s2[32];
    uint32_t combos = 0;
    for (uint8_t a = 0; a < n && hits < HUNT_MAX_HITS; a++)
    {
        for (uint8_t b = 0; b < n && hits < HUNT_MAX_HITS; b++)
        {
            if (b == a) { continue; }
            for (uint8_t c = 0; c < n && hits < HUNT_MAX_HITS; c++)
            {
                if (c == a || c == b) { continue; }
                if ((++combos & 0x3F) == 0) { wdg_kick(); }
                for (uint8_t proto = 0; proto < 3 && hits < HUNT_MAX_HITS; proto++)
                {
                    if (!(protos & (1 << proto))) { continue; }
                    hunt_frame(cm[a], cm[b], cm[c], proto, s1);
                    hunt_frame(cm[a], cm[b], cm[c], proto, s2);
                    /* fast filter over all pins at once: stable, not stuck 0, not stuck 1 */
                    uint32_t diff = 0, ones = 0xFFFFFFFF, zeros = 0xFFFFFFFF;
                    for (uint8_t i = 0; i < 32; i++)
                    {
                        diff |= s1[i] ^ s2[i]; ones &= s1[i]; zeros &= ~s1[i];
                    }
                    uint32_t good = all & ~diff & ~ones & ~zeros & ~cm[a] & ~cm[b];
                    if (!good) { continue; }
                    for (uint8_t d = 0; d < n && hits < HUNT_MAX_HITS; d++)
                    {
                        if (!(good & cm[d])) { continue; }
                        uint32_t v1 = 0;
                        for (uint8_t i = 0; i < 32; i++) { v1 = (v1 << 1) | ((s1[i] & cm[d]) ? 1 : 0); }
                        uint8_t *h = &out[hits * 9];
                        if ((uint16_t)(hits + 1) * 9 > out_max) { break; }
                        h[0] = cand[a]; h[1] = cand[b]; h[2] = cand[c]; h[3] = cand[d]; h[4] = proto;
                        h[5] = v1 >> 24; h[6] = v1 >> 16; h[7] = v1 >> 8; h[8] = v1;
                        hits++;
                    }
                }
            }
        }
    }
    for (uint8_t i = 0; i < n; i++) { pin_release(cand[i]); }
    return hits;
}

/* ------------------------------------------------------------------ watchdog + heartbeat */

static void hb_timer_cb(void *p)
{
    (void)p;
    /* feed only if the app task handled a heartbeat since the last tick */
    if (wdg_armed && !wdg_paused && hb_seen != hb_seen_at_last_tick) { WDG_Restart(); }
    hb_seen_at_last_tick = hb_seen;
    if (hb_sent != hb_seen) { return; }     /* previous one not handled yet: never flood the app queue */
    T_IO_MSG m;
    m.type = IO_MSG_TYPE_RESET_WDG_TIMER;
    m.subtype = 0;
    m.u.param = 0;
    if (app_send_msg_to_apptask(&m)) { hb_sent++; }
}

/* called by the app task for IO_MSG_TYPE_RESET_WDG_TIMER */
void onkar_heartbeat(void)
{
    hb_seen++;
    if (!wdg_armed && !wdg_paused && hb_seen >= 3)
    {
        /* 32.768 kHz / (63 + 1) = 512 Hz, count limit 15 -> 4095 ticks = 8 s, full chip reset */
        WDG_ClockEnable();
        WDG_Config(63, 15, RESET_ALL);
        WDG_Enable();
        WDG_Restart();
        wdg_armed = true;
    }
    if (driven_mask && os_sys_time_get() - last_cmd_ms > DEADMAN_MS) { release_all(); }
}

/* firmware update starting: never let our watchdog or pins get in its way */
void onkar_dfu_activity(void)
{
    if (!wdg_paused)
    {
        wdg_paused = true;
        if (wdg_armed) { WDG_Disable(); }
        release_all();
    }
}

void onkar_on_disconnect(void)
{
    release_all();
    if (wdg_paused)
    {
        /* an update that ends normally reboots the chip; this is an aborted one */
        wdg_paused = false;
        if (wdg_armed) { WDG_Enable(); WDG_Restart(); }
    }
}

void onkar_init(void)
{
    boot_reset_reason = (uint8_t)reset_reason_get();
    last_cmd_ms = os_sys_time_get();
    if (os_timer_create(&hb_timer, "onkar_hb", 0x4F4B, 1000, true, hb_timer_cb))
    {
        os_timer_start(&hb_timer);
    }
}

/* ------------------------------------------------------------------ command handler */

static uint8_t r[244];
static uint8_t big[HUNT_MAX_HITS * 9];

void onkar_tool_handle(uint8_t conn_id, uint8_t *p, uint16_t len)
{
    if (p == NULL || len == 0) { return; }
    last_cmd_ms = os_sys_time_get();
    memset(r, 0, sizeof(r));
    r[0] = p[0] | 0x80;

    switch (p[0])
    {
    case 0x01:
        r[1] = 'O'; r[2] = 'K'; r[3] = ONKAR_FW_VER;
        reply(conn_id, r, 4);
        break;

    case 0x02:
        {
            uint16_t raw = 0; uint8_t pct = 0; int8_t err = 0;
            uint16_t mv = onkar_battery_read(&raw, &pct, &err);
            r[1] = raw & 0xff; r[2] = raw >> 8; r[3] = mv & 0xff; r[4] = mv >> 8; r[5] = pct; r[6] = (uint8_t)err;
            reply(conn_id, r, 7);
        }
        break;

    case 0x03:
        if (len >= 3 && pin_valid(p[1])) { pin_hold(p[1], p[2]); r[1] = p[1]; r[2] = p[2]; reply(conn_id, r, 3); }
        else { r[1] = 0xEE; r[2] = len >= 2 ? p[1] : 0; reply(conn_id, r, 3); }
        break;

    case 0x04:
        if (len >= 3 && pin_valid(p[1]))
        {
            RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
            if (driven_mask & bit(p[1])) { r[1] = p[1]; r[2] = 0xDD; }       /* we are driving it */
            else { r[1] = p[1]; r[2] = pin_read(p[1], p[2]); }
            reply(conn_id, r, 3);
        }
        else { r[1] = 0xEE; reply(conn_id, r, 3); }
        break;

    case 0x05:
        {
            uint8_t pull = (len >= 2) ? p[1] : 0;
            uint64_t bits = 0, skipped = 0;
            RCC_PeriphClockCmd(APBPeriph_GPIO, APBPeriph_GPIO_CLOCK, ENABLE);
            for (uint8_t pin = 0; pin < 40; pin++)
            {
                if (!pin_valid(pin) || (driven_mask & bit(pin))) { skipped |= bit(pin); continue; }
                if (pin_read(pin, pull)) { bits |= bit(pin); }
            }
            memcpy(&r[1], &bits, 5);
            memcpy(&r[6], &skipped, 5);
            reply(conn_id, r, 11);
        }
        break;

    case 0x08:
        if (len >= 5 && pin_valid(p[1]))
        {
            uint16_t ms = p[3] | (p[4] << 8);
            if (ms > 1000) { ms = 1000; }
            pin_hold(p[1], p[2]);
            platform_delay_ms(ms);
            pin_release(p[1]);
            r[1] = p[1];
            reply(conn_id, r, 2);
        }
        else { r[1] = 0xEE; reply(conn_id, r, 2); }
        break;

    case 0x0A:
        if (len >= 2 && pin_valid(p[1])) { pin_release(p[1]); r[1] = p[1]; }
        else { r[1] = 0xEE; }
        reply(conn_id, r, 2);
        break;

    case 0x0B:
        r[1] = release_all();
        reply(conn_id, r, 2);
        break;

    case 0x10:
        {
            uint32_t up = (uint32_t)(os_sys_time_get() / 1000);
            r[1] = ONKAR_FW_VER;
            memcpy(&r[2], &up, 4);
            r[6] = boot_reset_reason;
            r[7] = (wdg_armed ? 1 : 0) | (wdg_paused ? 2 : 0);
            memcpy(&r[8], &driven_mask, 5);
            uint32_t hb = hb_seen;
            memcpy(&r[13], &hb, 4);
            reply(conn_id, r, 17);
        }
        break;

    case 0x11:
        {
            uint8_t k = 1;
            for (uint8_t ch = 0; ch < 8; ch++)
            {
                uint8_t pin = P2_0 + ch;
                uint16_t raw = 0xFFFF, mv = 0xFFFF; int8_t err = 0;
                if (!(driven_mask & bit(pin)) && !pin_is_sw_output(pin))
                {
                    bool was_saved = (orig_saved & bit(pin)) != 0;
                    remember(pin);
                    Pinmux_Config(pin, IDLE_MODE);
                    Pad_Config(pin, PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
                    mv = adc_once(EXT_SINGLE_ENDED(ch), &raw, &err);
                    restore(pin);
                    if (!was_saved) { orig_saved &= ~bit(pin); }
                }
                r[k++] = raw & 0xff; r[k++] = raw >> 8; r[k++] = mv & 0xff; r[k++] = mv >> 8;
            }
            uint16_t raw = 0; int8_t err = 0;
            uint16_t mv = adc_once(INTERNAL_VBAT_MODE, &raw, &err);
            r[k++] = raw & 0xff; r[k++] = raw >> 8; r[k++] = mv & 0xff; r[k++] = mv >> 8;
            reply(conn_id, r, k);
        }
        break;

    case 0x12:
        if (len >= 3)
        {
            T_I2C b;
            uint8_t st = i2c_open(&b, p[1], p[2]);
            uint8_t cnt = 0;
            if (st == 0)
            {
                for (uint8_t a = 0x08; a < 0x78; a++)
                {
                    i2c_start(&b);
                    bool ack = i2c_wbyte(&b, a << 1);
                    i2c_stop(&b);
                    if (ack) { r[3 + (a >> 3)] |= 1 << (a & 7); cnt++; }
                }
            }
            if (st != 3) { pin_release(p[1]); pin_release(p[2]); }
            r[1] = st; r[2] = cnt;
            reply(conn_id, r, 19);
        }
        break;

    case 0x13:
        if (len >= 6)
        {
            T_I2C b;
            uint8_t n = p[5] > 64 ? 64 : p[5];
            uint8_t st = i2c_open(&b, p[1], p[2]);
            if (st == 0)
            {
                i2c_start(&b);
                if (!i2c_wbyte(&b, p[3] << 1) || !i2c_wbyte(&b, p[4])) { st = 4; }
                else
                {
                    i2c_start(&b);
                    if (!i2c_wbyte(&b, (p[3] << 1) | 1)) { st = 5; }
                    else { for (uint8_t i = 0; i < n; i++) { r[3 + i] = i2c_rbyte(&b, i + 1 < n); } }
                }
                i2c_stop(&b);
            }
            if (st != 3) { pin_release(p[1]); pin_release(p[2]); }
            r[1] = st; r[2] = (st == 0) ? n : 0;
            reply(conn_id, r, 3 + r[2]);
        }
        break;

    case 0x14:
        if (len >= 5 && p[4] <= len - 5)
        {
            T_I2C b;
            uint8_t st = i2c_open(&b, p[1], p[2]);
            if (st == 0)
            {
                i2c_start(&b);
                if (!i2c_wbyte(&b, p[3] << 1)) { st = 4; }
                for (uint8_t i = 0; st == 0 && i < p[4]; i++) { if (!i2c_wbyte(&b, p[5 + i])) { st = 6; } }
                i2c_stop(&b);
            }
            if (st != 3) { pin_release(p[1]); pin_release(p[2]); }
            r[1] = st;
            reply(conn_id, r, 2);
        }
        break;

    case 0x15:
        if (len >= 8)
        {
            uint64_t mask = 0;
            memcpy(&mask, &p[3], 5);
            uint8_t ncand = 0;
            uint8_t protos = (p[2] >> 4) & 0x07;
            if (protos == 0) { protos = 0x07; }
            uint16_t hits = hunt(p[1], p[2] & 0x03, protos, mask, big, sizeof(big), &ncand);
            r[1] = 0; r[2] = ncand; r[3] = (uint8_t)hits;
            memcpy(&r[4], big, hits * 9);
            reply(conn_id, r, 4 + hits * 9);
        }
        break;

    case 0x16:
        if (len >= 9 && p[7] <= len - 9)
        {
            T_SPI s;
            uint8_t nw = p[7], nr = p[8 + nw];
            if (nr > 200) { nr = 200; }
            if (!spi_open(&s, p[1], p[2], p[3], p[4], p[5], p[6])) { r[1] = 0xEE; reply(conn_id, r, 2); break; }
            g_clr(s.cs);
            for (uint8_t i = 0; i < nw; i++) { spi_wbyte(&s, p[8 + i], i == 0); }
            if (nr && s.miso)
            {
                if (s.miso == s.mosi) { g_in(s.mosi); }
                for (uint8_t i = 0; i < nr; i++) { r[2 + i] = spi_rbyte(&s); }
                if (s.miso == s.mosi) { g_out(s.mosi, 0); }
            }
            g_set(s.cs);
            r[1] = nr;
            reply(conn_id, r, 2 + nr);
        }
        break;

    case 0x17:
        if (len >= 8 && p[6] <= len - 8)
        {
            T_SPI s;
            uint8_t nh = p[6];
            if (len < 8 + nh + 6) { r[1] = 0xEE; reply(conn_id, r, 2); break; }
            uint8_t hi = p[7 + nh], lo = p[8 + nh];
            uint32_t count;
            memcpy(&count, &p[9 + nh], 4);
            if (count > 368u * 448u) { count = 368u * 448u; }
            if (!spi_open(&s, p[1], p[2], p[3], 0xFF, p[4], p[5])) { r[1] = 0xEE; reply(conn_id, r, 2); break; }
            g_clr(s.cs);
            for (uint8_t i = 0; i < nh; i++) { spi_wbyte(&s, p[7 + i], i == 0); }
            for (uint32_t px = 0; px < count; px++)
            {
                spi_wbyte(&s, hi, false); spi_wbyte(&s, lo, false);
                if ((px & 0x3FFF) == 0) { wdg_kick(); }
            }
            g_set(s.cs);
            r[1] = 0;
            reply(conn_id, r, 2);
        }
        break;

    case 0x18:      /* read-only dump of every pad: b0 b1 pinmux, pins 0..38 (H pins only READ) */
        {
            uint8_t k = 1;
            for (uint8_t pin = 0; pin <= 38; pin++)
            {
                if (pin == 31) { r[k++] = 0; r[k++] = 0; r[k++] = 0; continue; }
                uint8_t a = (uint8_t)PINADDR_TABLE[pin];
                r[k++] = btaon_fast_read_safe(a);
                r[k++] = btaon_fast_read_safe(a + 1);
                r[k++] = pmx_get(pin);
            }
            reply(conn_id, r, k);
        }
        break;

    case 0x19:      /* float test: pin -> input, no pull, for ms (<= 3000), then exact restore */
        if (len >= 4 && pin_valid(p[1]) && !(driven_mask & bit(p[1])))
        {
            uint16_t ms = p[2] | (p[3] << 8);
            if (ms > 3000) { ms = 3000; }
            if (pin_is_sw_output(p[1])) { r[1] = p[1]; r[2] = 0x80; reply(conn_id, r, 3); break; }
            bool was_saved = (orig_saved & bit(p[1])) != 0;
            remember(p[1]);
            Pinmux_Config(p[1], IDLE_MODE);
            Pad_Config(p[1], PAD_SW_MODE, PAD_IS_PWRON, PAD_PULL_NONE, PAD_OUT_DISABLE, PAD_OUT_LOW);
            for (uint16_t t = 0; t < ms; t += 100) { platform_delay_ms(100); wdg_kick(); }
            restore(p[1]);
            if (!was_saved) { orig_saved &= ~bit(p[1]); }
            r[1] = p[1]; r[2] = 0;
            reply(conn_id, r, 3);
        }
        else { r[1] = 0xEE; reply(conn_id, r, 3); }
        break;

    default:
        r[1] = 0xEE;
        reply(conn_id, r, 2);
        break;
    }
}
